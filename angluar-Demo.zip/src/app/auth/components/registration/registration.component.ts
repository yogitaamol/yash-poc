import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})

export class RegistrationComponent implements OnInit {

  
  status : any  = "UK";
  status_values: any = ["UK", "India", "US"];

  
  frmRegister: FormGroup;

  constructor() {
    this.frmRegister= this.createFormGroup();
   }

  createFormGroup() 
  {
    return new FormGroup({
      // email: new FormControl('',[Validators.required, Validators.email]),
      // password: new FormControl('',[Validators.required]),
      // selectcountry: new FormControl('',[Validators.required]), 
      // termsncondition: new FormControl('',[Validators.required])


        'email': new FormControl(null, [Validators.required, Validators.email]),
        'password' : new FormControl(null, [Validators.required]),
        'selectcountry' : new FormControl(null, [Validators.required]), 
        'termsncondition' : new FormControl(null, [Validators.required])

    });
  }

  onSubmit(){
      console.log(this.frmRegister.value);
      this.frmRegister.reset();
      
    }
  
  // export class RegistrationComponent implements OnInit {
  
  // frmRegister: FormGroup | undefined;

  ngOnInit(): void {

    // this.frmRegister = new FormGroup({

    //     'email': new FormControl(null, [Validators.required, Validators.email]),
    //     'password' : new FormControl(null, [Validators.required]),
    //     'selectcountry' : new FormControl(null, [Validators.required]), 
    //     'termsncondition' : new FormControl(null, [Validators.required])

    // })
  }
  // clicksub(){
  //   console.log(this.frmRegister.value);
  //   this.frmRegister.reset();
    
  // }

}
