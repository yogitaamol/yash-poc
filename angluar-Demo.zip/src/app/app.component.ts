import { Component, OnInit } from '@angular/core';
import { UserData } from './user-data';

import { DataServiceService } from './data-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'angular-project';

  constructor(private appservice: DataServiceService ) { }

  users: UserData[] = [];


  ngOnInit(){
    this.getUsers();
  }
  getUsers() {
    this.appservice.getUsers().subscribe((data: UserData[]) => {
      this.users = data;
    });

  }
}




