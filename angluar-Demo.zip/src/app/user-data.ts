export class UserData {
    constructor(
    public id = 0,
    public name = '',
    public email = '',
    public contact='',
    ){}
}
